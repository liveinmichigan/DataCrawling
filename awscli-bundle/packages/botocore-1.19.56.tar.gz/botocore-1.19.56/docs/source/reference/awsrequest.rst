.. _ref-awsrequest:

================================
AWS Request Reference
================================

botocore.awsrequest
-------------------

.. autoclass:: botocore.awsrequest.AWSPreparedRequest
   :members:


.. autoclass:: botocore.awsrequest.AWSResponse
   :members:
